// Game currency supplier adapter (wholesale top-up provider).
//
// SUPPLIER_MODE=mock -> pretends to deliver after a short delay.
// SUPPLIER_MODE=live -> implement topupLive() / checkPlayerLive() against your supplier's API docs.
//
// Contract:
//   checkPlayer({ game, playerId, zoneId }) -> { valid: boolean, nickname?: string }
//   topup({ game, playerId, zoneId, amount, orderId }) -> { supplierRef }   (throws on failure)
// Always pass orderId as the idempotency key so a retry can never deliver twice.
const MODE = process.env.SUPPLIER_MODE || "mock";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function checkPlayerMock({ playerId }) {
  // Mock rule: IDs ending in 0000 are "not found" so you can test the failure path.
  if (!/^\d{5,16}$/.test(playerId) || playerId.endsWith("0000")) return { valid: false };
  return { valid: true, nickname: "Player_" + playerId.slice(-4) };
}

async function topupMock({ orderId, playerId }) {
  await sleep(1500);
  if (playerId.endsWith("9999")) throw new Error("Supplier rejected the top-up (mock failure)");
  return { supplierRef: "SUP-" + orderId };
}

async function checkPlayerLive(/* { game, playerId, zoneId } */) {
  // TODO: call the supplier's "check player / role" endpoint.
  throw new Error("SUPPLIER_MODE=live is not configured yet. See services/supplier.js");
}

async function topupLive(/* { game, playerId, zoneId, amount, orderId } */) {
  // TODO: call the supplier's "create order" endpoint with SUPPLIER_API_KEY from .env.
  // Map your pack (game.slug + amount) to the supplier's product/SKU code.
  throw new Error("SUPPLIER_MODE=live is not configured yet. See services/supplier.js");
}

module.exports = {
  MODE,
  checkPlayer: (a) => (MODE === "live" ? checkPlayerLive(a) : checkPlayerMock(a)),
  topup: (a) => (MODE === "live" ? topupLive(a) : topupMock(a)),
};
