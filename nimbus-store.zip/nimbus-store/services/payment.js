// Payment gateway adapter.
//
// PAYMENT_MODE=mock  -> fake payments for local development (nothing real is charged,
//                       the QR code is NOT scannable by a bank app).
// PAYMENT_MODE=live  -> you implement createLive() with your provider (Bakong KHQR,
//                       ABA PayWay, Wing, ...). Their docs and your merchant keys are required.
//
// Contract the rest of the app relies on:
//   createPayment({ orderId, amountCents, method }) -> { providerRef, type, payload, expiresAt }
//   verifyWebhook(rawBody, headers)                 -> { providerRef, amountCents } | throws
const crypto = require("crypto");

const MODE = process.env.PAYMENT_MODE || "mock";
const TTL_MIN = Number(process.env.PAYMENT_TTL_MINUTES || 10);

function createMock({ orderId, amountCents, method }) {
  const providerRef = "MOCK-" + crypto.randomBytes(6).toString("hex").toUpperCase();
  const expiresAt = new Date(Date.now() + TTL_MIN * 60 * 1000).toISOString();
  return {
    providerRef,
    type: method === "khqr" ? "qr" : "redirect",
    // For "qr" this string is encoded into a QR image. A real KHQR payload comes from your provider/Bakong.
    payload: `NIMBUS-MOCK-KHQR|${orderId}|${(amountCents / 100).toFixed(2)}USD|${providerRef}`,
    expiresAt,
  };
}

async function createLive(/* { orderId, amountCents, method } */) {
  // TODO: call your payment provider here and return { providerRef, type, payload, expiresAt }.
  //  - Use the provider's transaction id as providerRef.
  //  - For KHQR, payload is the KHQR string returned by the provider.
  //  - Keep API keys in .env, never in the frontend.
  throw new Error("PAYMENT_MODE=live is not configured yet. See services/payment.js");
}

async function createPayment(args) {
  return MODE === "live" ? createLive(args) : createMock(args);
}

// Webhooks must be signed: HMAC-SHA256 of the raw body using WEBHOOK_SECRET, sent in x-signature.
// Adjust header name / algorithm to match what your provider actually sends.
function verifyWebhook(rawBody, headers) {
  const secret = process.env.WEBHOOK_SECRET;
  if (!secret) throw new Error("WEBHOOK_SECRET is not set");
  const given = String(headers["x-signature"] || "");
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(given), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new Error("bad signature");
  const body = JSON.parse(rawBody.toString("utf8"));
  if (body.status !== "paid") throw new Error("not a paid event");
  return { providerRef: String(body.providerRef), amountCents: Number(body.amountCents) };
}

module.exports = { MODE, createPayment, verifyWebhook };
