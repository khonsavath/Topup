// SQLite database: schema + first-run sample data.
const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

const file = process.env.DB_FILE || path.join(__dirname, "data", "nimbus.db");
fs.mkdirSync(path.dirname(file), { recursive: true });

const db = new Database(file);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS games (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  slug        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  initials    TEXT NOT NULL,
  hue         INTEGER NOT NULL DEFAULT 200,
  popular     INTEGER NOT NULL DEFAULT 0,
  image       TEXT,
  fit         TEXT,
  currency    TEXT NOT NULL,            -- what the player receives: Diamonds, UC, Robux...
  needs_zone  INTEGER NOT NULL DEFAULT 0,
  active      INTEGER NOT NULL DEFAULT 1,
  sort        INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS packs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  game_id     INTEGER NOT NULL REFERENCES games(id),
  amount      INTEGER NOT NULL,         -- e.g. 172 diamonds
  price_cents INTEGER NOT NULL,         -- price in USD cents (integers, never floats)
  active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
  id            TEXT PRIMARY KEY,       -- public id, e.g. NB-7F3K9QXA
  game_id       INTEGER NOT NULL REFERENCES games(id),
  pack_id       INTEGER NOT NULL REFERENCES packs(id),
  player_id     TEXT NOT NULL,
  zone_id       TEXT,
  email         TEXT,
  amount        INTEGER NOT NULL,       -- snapshot of the pack amount at purchase time
  price_cents   INTEGER NOT NULL,       -- snapshot of the price at purchase time
  status        TEXT NOT NULL,          -- pending_payment | paid | delivering | completed | failed | expired
  supplier_ref  TEXT,
  failure       TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  paid_at       TEXT,
  delivered_at  TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id     TEXT NOT NULL REFERENCES orders(id),
  method       TEXT NOT NULL,           -- khqr | card
  provider_ref TEXT NOT NULL UNIQUE,
  amount_cents INTEGER NOT NULL,
  status       TEXT NOT NULL,           -- pending | paid | expired
  expires_at   TEXT NOT NULL,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);
`);

// ---- sample catalogue (prices are SAMPLE values, replace with your own) ----
const PACKS = {
  Diamonds: [[56, 89], [112, 169], [223, 329], [570, 829], [1163, 1649]],
  Robux: [[400, 499], [800, 999], [1700, 1999], [4500, 4999]],
  UC: [[60, 99], [325, 499], [660, 999], [1800, 2499], [3850, 4999]],
  Crystals: [[60, 99], [300, 449], [980, 1399], [1980, 2799], [3280, 4599]],
};

const GAMES = [
  // slug, name, initials, hue, popular, image, fit, currency, needsZone
  ["mobile-legends", "Mobile Legends", "ML", 265, 1, "images/mobile-legends.png", null, "Diamonds", 1],
  ["free-fire", "Free Fire", "FF", 12, 1, "images/free-fire.png", null, "Diamonds", 0],
  ["roblox", "Roblox", "RB", 210, 1, "images/roblox.png", "contain", "Robux", 0],
  ["pubg-battlegrounds", "PUBG Battlegrounds", "PB", 300, 1, "images/pubg.png", null, "UC", 0],
  ["rune-quest", "Rune Quest", "RQ", 45, 0, null, null, "Crystals", 0],
  ["turbo-drift", "Turbo Drift", "TD", 190, 0, null, null, "Crystals", 0],
  ["neon-strike", "Neon Strike", "NS", 320, 1, null, null, "Crystals", 0],
  ["mystic-chess", "Mystic Chess", "MC", 285, 1, null, null, "Crystals", 0],
  ["harvest-valley", "Harvest Valley", "HV", 120, 0, null, null, "Crystals", 0],
  ["skyward-legends", "Skyward Legends", "SL", 230, 0, null, null, "Crystals", 0],
  ["ghost-ops", "Ghost Ops", "GO", 160, 0, null, null, "Crystals", 0],
  ["tidal-realm", "Tidal Realm", "TR", 178, 0, null, null, "Crystals", 0],
  ["blade-saga", "Blade Saga", "BS", 350, 0, null, null, "Crystals", 0],
  ["cosmic-kart", "Cosmic Kart", "CK", 25, 0, null, null, "Crystals", 0],
  ["event-tickets", "Event Tickets", "ET", 80, 0, null, null, "Crystals", 0],
];

function seed() {
  if (db.prepare("SELECT COUNT(*) AS n FROM games").get().n > 0) return;
  const addGame = db.prepare(
    `INSERT INTO games (slug,name,initials,hue,popular,image,fit,currency,needs_zone,sort)
     VALUES (?,?,?,?,?,?,?,?,?,?)`
  );
  const addPack = db.prepare("INSERT INTO packs (game_id,amount,price_cents) VALUES (?,?,?)");
  db.transaction(() => {
    GAMES.forEach((g, i) => {
      const id = addGame.run(...g, i).lastInsertRowid;
      PACKS[g[7]].forEach(([amount, cents]) => addPack.run(id, amount, cents));
    });
  })();
}
seed();

module.exports = db;
