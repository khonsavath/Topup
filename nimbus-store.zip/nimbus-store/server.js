require("dotenv").config();
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const QRCode = require("qrcode");

const db = require("./db");
const payment = require("./services/payment");
const supplier = require("./services/supplier");

const app = express();
const PORT = Number(process.env.PORT || 3000);
if (process.env.TRUST_PROXY) app.set("trust proxy", Number(process.env.TRUST_PROXY));

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "https://fonts.googleapis.com"],
        styleSrcAttr: ["'unsafe-inline'"],
        fontSrc: ["https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
        upgradeInsecureRequests: null, // keep plain http working on localhost
      },
    },
  })
);

// Keep the raw body: the payment webhook signature is computed over the exact bytes.
app.use(express.json({ limit: "10kb", verify: (req, _res, buf) => { req.rawBody = buf; } }));

// ---------------------------------------------------------------- helpers
const ID_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function newOrderId() {
  const bytes = crypto.randomBytes(8);
  let s = "";
  for (const b of bytes) s += ID_ALPHABET[b % ID_ALPHABET.length];
  return "NB-" + s;
}
const safeEqual = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const fail = (res, status, error, extra = {}) => res.status(status).json({ error, ...extra });

const q = {
  games: db.prepare("SELECT * FROM games WHERE active=1 ORDER BY sort"),
  packsByGame: db.prepare("SELECT id, amount, price_cents FROM packs WHERE game_id=? AND active=1 ORDER BY amount"),
  game: db.prepare("SELECT * FROM games WHERE slug=? AND active=1"),
  pack: db.prepare("SELECT * FROM packs WHERE id=? AND game_id=? AND active=1"),
  order: db.prepare(
    `SELECT o.*, g.name AS game_name, g.slug AS game_slug, g.currency AS currency,
            (SELECT expires_at FROM payments WHERE order_id=o.id ORDER BY id DESC LIMIT 1) AS expires_at
     FROM orders o JOIN games g ON g.id=o.game_id WHERE o.id=?`
  ),
};

// ---------------------------------------------------------------- order lifecycle
function expireStale() {
  const now = new Date().toISOString();
  db.transaction(() => {
    db.prepare(
      `UPDATE orders SET status='expired'
       WHERE status='pending_payment'
         AND id IN (SELECT order_id FROM payments WHERE status='pending' AND expires_at < ?)`
    ).run(now);
    db.prepare("UPDATE payments SET status='expired' WHERE status='pending' AND expires_at < ?").run(now);
  })();
}
setInterval(expireStale, 30 * 1000).unref();

// Marks a payment as paid. Safe to call twice (webhooks are often retried).
const markPaid = db.transaction((providerRef, amountCents) => {
  const p = db.prepare("SELECT * FROM payments WHERE provider_ref=?").get(providerRef);
  if (!p) return { ok: false, code: 404, error: "unknown_payment" };
  if (amountCents != null && amountCents !== p.amount_cents) return { ok: false, code: 400, error: "amount_mismatch" };
  if (p.status === "paid") return { ok: true, orderId: p.order_id, already: true };
  // Money that arrives just after the QR expired is still honoured (order is 'expired' or 'pending_payment').
  db.prepare("UPDATE payments SET status='paid' WHERE id=?").run(p.id);
  db.prepare(
    "UPDATE orders SET status='paid', paid_at=datetime('now') WHERE id=? AND status IN ('pending_payment','expired')"
  ).run(p.order_id);
  return { ok: true, orderId: p.order_id };
});

// Delivers the game currency. The UPDATE ... WHERE status='paid' claim makes it run at most once per order.
async function fulfill(orderId) {
  const claimed = db.prepare("UPDATE orders SET status='delivering' WHERE id=? AND status='paid'").run(orderId).changes;
  if (!claimed) return;
  const o = q.order.get(orderId);
  try {
    const r = await supplier.topup({
      game: { slug: o.game_slug, name: o.game_name },
      playerId: o.player_id,
      zoneId: o.zone_id,
      amount: o.amount,
      orderId: o.id, // idempotency key
    });
    db.prepare("UPDATE orders SET status='completed', supplier_ref=?, delivered_at=datetime('now') WHERE id=?").run(r.supplierRef, orderId);
  } catch (err) {
    // Customer has paid but delivery failed: needs a retry or a refund by the shop owner.
    console.error(`[fulfill] order ${orderId} failed:`, err.message);
    db.prepare("UPDATE orders SET status='failed', failure=? WHERE id=?").run(String(err.message).slice(0, 200), orderId);
  }
}

// ---------------------------------------------------------------- public API
// Signed payment webhook (mounted before the rate limiter on purpose).
app.post("/api/payments/webhook", (req, res) => {
  let evt;
  try {
    evt = payment.verifyWebhook(req.rawBody || Buffer.alloc(0), req.headers);
  } catch (e) {
    return fail(res, 401, "invalid_webhook");
  }
  const r = markPaid(evt.providerRef, evt.amountCents);
  if (!r.ok) return fail(res, r.code, r.error);
  if (!r.already) fulfill(r.orderId);
  res.json({ ok: true });
});

app.use("/api", rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));

app.get("/api/config", (_req, res) => {
  res.json({ paymentMode: payment.MODE, supplierMode: supplier.MODE, mock: payment.MODE === "mock" });
});

app.get("/api/games", (_req, res) => {
  const games = q.games.all().map((g) => ({
    slug: g.slug, name: g.name, initials: g.initials, hue: g.hue, popular: !!g.popular,
    image: g.image, fit: g.fit, currency: g.currency, needsZone: !!g.needs_zone,
    packs: q.packsByGame.all(g.id).map((p) => ({ id: p.id, amount: p.amount, priceCents: p.price_cents })),
  }));
  res.json({ games });
});

const PLAYER_RE = /^\d{5,16}$/;
const ZONE_RE = /^\d{1,6}$/;

app.get("/api/players/check", async (req, res) => {
  const game = q.game.get(String(req.query.game || ""));
  if (!game) return fail(res, 404, "unknown_game");
  const playerId = String(req.query.playerId || "");
  const zoneId = String(req.query.zoneId || "");
  if (!PLAYER_RE.test(playerId) || (game.needs_zone && !ZONE_RE.test(zoneId))) return res.json({ valid: false });
  try {
    res.json(await supplier.checkPlayer({ game: { slug: game.slug }, playerId, zoneId }));
  } catch (e) {
    fail(res, 502, "check_unavailable");
  }
});

app.post("/api/orders", rateLimit({ windowMs: 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }), async (req, res) => {
  const b = req.body || {};
  const game = q.game.get(String(b.gameSlug || ""));
  if (!game) return fail(res, 400, "unknown_game");
  const pack = q.pack.get(Number(b.packId), game.id);
  if (!pack) return fail(res, 400, "unknown_pack");
  const playerId = String(b.playerId || "").trim();
  const zoneId = String(b.zoneId || "").trim();
  const email = String(b.email || "").trim();
  const method = String(b.method || "");
  if (!PLAYER_RE.test(playerId)) return fail(res, 400, "invalid_player_id");
  if (game.needs_zone && !ZONE_RE.test(zoneId)) return fail(res, 400, "invalid_zone_id");
  if (email && !/^[^\s@]{1,64}@[^\s@]{1,255}$/.test(email)) return fail(res, 400, "invalid_email");
  if (!["khqr", "card"].includes(method)) return fail(res, 400, "invalid_method");

  try {
    const check = await supplier.checkPlayer({ game: { slug: game.slug }, playerId, zoneId });
    if (!check.valid) return fail(res, 422, "player_not_found");
  } catch (e) {
    return fail(res, 502, "check_unavailable");
  }

  // The price always comes from the database, never from the browser.
  const orderId = newOrderId();
  db.prepare(
    `INSERT INTO orders (id,game_id,pack_id,player_id,zone_id,email,amount,price_cents,status)
     VALUES (?,?,?,?,?,?,?,?, 'pending_payment')`
  ).run(orderId, game.id, pack.id, playerId, game.needs_zone ? zoneId : null, email || null, pack.amount, pack.price_cents);

  let pay;
  try {
    pay = await payment.createPayment({ orderId, amountCents: pack.price_cents, method });
  } catch (e) {
    console.error("[payment] create failed:", e.message);
    db.prepare("UPDATE orders SET status='failed', failure='payment_unavailable' WHERE id=?").run(orderId);
    return fail(res, 502, "payment_unavailable");
  }
  db.prepare(
    "INSERT INTO payments (order_id,method,provider_ref,amount_cents,status,expires_at) VALUES (?,?,?,?, 'pending', ?)"
  ).run(orderId, method, pay.providerRef, pack.price_cents, pay.expiresAt);

  const qr = pay.type === "qr" ? await QRCode.toDataURL(pay.payload, { margin: 1, width: 300 }) : null;
  res.status(201).json({
    orderId, status: "pending_payment", priceCents: pack.price_cents, amount: pack.amount, currency: game.currency,
    gameName: game.name, expiresAt: pay.expiresAt,
    payment: { method, type: pay.type, qr, mock: payment.MODE === "mock" },
  });
});

app.get("/api/orders/:id", (req, res) => {
  expireStale();
  const o = q.order.get(String(req.params.id).toUpperCase());
  if (!o) return fail(res, 404, "order_not_found");
  res.json({
    orderId: o.id, status: o.status, gameName: o.game_name, amount: o.amount, currency: o.currency,
    priceCents: o.price_cents, expiresAt: o.expires_at, supplierRef: o.status === "completed" ? o.supplier_ref : null,
    problem: o.status === "failed" ? "delivery_failed" : null,
  });
});

// Development only: pretend the customer paid. Disabled automatically in live mode.
app.post("/api/dev/pay/:orderId", (req, res) => {
  if (payment.MODE !== "mock") return fail(res, 404, "not_found");
  const p = db.prepare("SELECT provider_ref FROM payments WHERE order_id=? ORDER BY id DESC LIMIT 1").get(String(req.params.orderId).toUpperCase());
  if (!p) return fail(res, 404, "order_not_found");
  const r = markPaid(p.provider_ref, null);
  if (!r.ok) return fail(res, r.code, r.error);
  if (!r.already) fulfill(r.orderId);
  res.json({ ok: true });
});

// Owner view of recent orders. Disabled unless ADMIN_TOKEN is set.
app.get("/api/admin/orders", (req, res) => {
  const token = process.env.ADMIN_TOKEN;
  if (!token || !safeEqual(req.headers["x-admin-token"] || "", token)) return fail(res, 404, "not_found");
  const rows = db.prepare(
    `SELECT o.id, g.name AS game, o.amount, o.price_cents, o.player_id, o.zone_id, o.status, o.supplier_ref, o.failure, o.created_at, o.paid_at, o.delivered_at
     FROM orders o JOIN games g ON g.id=o.game_id ORDER BY o.created_at DESC LIMIT 200`
  ).all();
  res.json({ orders: rows });
});

// ---------------------------------------------------------------- static frontend + errors
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", (_req, res) => fail(res, 404, "not_found"));
app.use((err, _req, res, _next) => {
  if (err.type === "entity.parse.failed") return fail(res, 400, "invalid_json");
  console.error(err);
  fail(res, 500, "server_error");
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Nimbus Topup running at http://localhost:${PORT}  (payment: ${payment.MODE}, supplier: ${supplier.MODE})`);
  });
}
module.exports = app;
