# Nimbus Topup (Full-stack)

ហាងបញ្ចូលលុយហ្គេម៖ Frontend (HTML/CSS/JS) + Backend (Node.js Express) + Database (SQLite)។
ពេលនេះ **ការទូទាត់ និងអ្នកផ្គត់ផ្គង់ជា mock** (គ្មានលុយពិត គ្មានការបញ្ចូលពេជ្រពិត)។ ដើម្បីដំណើរការពិត ត្រូវភ្ជាប់ API ពិតរបស់អ្នក (មើលខាងក្រោម)។

## ដំណើរការលើកុំព្យូទ័រ

ត្រូវការ Node.js 18 ឬថ្មីជាងនេះ។

```bash
npm install
cp .env.example .env      # បន្ទាប់មកកែ WEBHOOK_SECRET (និង ADMIN_TOKEN បើចង់ប្រើ)
npm start
```

បើក http://localhost:3000 ។ ចុចហ្គេម → ជ្រើសកញ្ចប់ → បញ្ចូល Player ID → បង់ប្រាក់ → ចុច **Simulate payment (demo)** ដើម្បីសាកល្បង។

ចំណាំសាកល្បង (ម៉ូដ mock)៖ Player ID ដែលបញ្ចប់ដោយ `0000` = រកមិនឃើញគណនី, ដែលបញ្ចប់ដោយ `9999` = អ្នកផ្គត់ផ្គង់បដិសេធការបញ្ចូល។

## រចនាសម្ព័ន្ធឯកសារ

```
server.js              API, ការគ្រប់គ្រង order, webhook, ការបញ្ចូល (fulfill)
db.js                  តារាង SQLite + ទិន្នន័យគំរូ (ហ្គេម, កញ្ចប់, តម្លៃ)
services/payment.js    ✱ ត្រង់នេះដែលអ្នកភ្ជាប់ KHQR / ABA PayWay / Wing
services/supplier.js   ✱ ត្រង់នេះដែលអ្នកភ្ជាប់ API អ្នកផ្គត់ផ្គង់ពេជ្រ
public/                Frontend (index.html, style.css, script.js, images/)
.env.example           ការកំណត់ (ចម្លងទៅ .env)
```

## ដំណើរការរបស់ប្រព័ន្ធ

1. អតិថិជនជ្រើសកញ្ចប់ + Player ID → `POST /api/orders`។ Server ផ្ទៀងផ្ទាត់ Player ID, **គណនាតម្លៃពី database (មិនជឿ browser)**, បង្កើតការទូទាត់ ហើយបញ្ជូន QR មកវិញ។
2. Frontend ពិនិត្យស្ថានភាព `GET /api/orders/:id` រៀងរាល់ ២ វិនាទី។
3. ធនាគារ/gateway ហៅ `POST /api/payments/webhook` (មានហត្ថលេខា HMAC) → order ប្តូរទៅ `paid`។
4. Server ហៅអ្នកផ្គត់ផ្គង់ដើម្បីបញ្ចូលពេជ្រ → `completed` (ឬ `failed` បើមានបញ្ហា)។

ស្ថានភាព order៖ `pending_payment → paid → delivering → completed` (ឬ `failed` / `expired`)។

## ការធ្វើឱ្យដំណើរការពិត (ត្រូវការគណនី និង key របស់អ្នក)

ខ្ញុំមិនមាន key ទាំងនេះទេ ដូច្នេះអ្នកត្រូវធ្វើខ្លួនឯង ឬឱ្យអ្នកអភិវឌ្ឍន៍ធ្វើ៖

1. **ការទូទាត់**៖ ចុះឈ្មោះ merchant (Bakong KHQR, ABA PayWay, Wing…)។ បំពេញ `createLive()` ក្នុង `services/payment.js` ហើយកែ `verifyWebhook()` ឱ្យត្រូវនឹងវិធីដែល provider ចុះហត្ថលេខា។ បន្ទាប់មកកំណត់ `PAYMENT_MODE=live`។
2. **អ្នកផ្គត់ផ្គង់**៖ ចុះកិច្ចព្រមព្រៀងជាមួយអ្នកចែកចាយផ្លូវការ។ បំពេញ `checkPlayerLive()` និង `topupLive()` ក្នុង `services/supplier.js` ព្រមទាំងផ្គូផ្គងកញ្ចប់របស់អ្នកទៅនឹងកូដផលិតផលរបស់គេ។ បន្ទាប់មកកំណត់ `SUPPLIER_MODE=live`។
3. ជំនួសតម្លៃគំរូក្នុង `db.js` (តារាង `packs`) ដោយតម្លៃពិតរបស់អ្នក។ ប្រសិនបើ database មានរួចហើយ ត្រូវលុបឯកសារ `data/nimbus.db` ឬកែតាម SQL។
4. Deploy ជាមួយ HTTPS (ឧ. nginx/Cloudflare ឬ Render/Railway) ហើយកំណត់ `TRUST_PROXY=1`។ Webhook ត្រូវតែជា URL សាធារណៈ។

## សុវត្ថិភាព (មានរួចហើយ)

- តម្លៃមកពី database ជានិច្ច, ការបញ្ចូលទិន្នន័យត្រូវបានផ្ទៀងផ្ទាត់, SQL ប្រើ parameter។
- Webhook ត្រូវមានហត្ថលេខា HMAC និងផ្ទៀងផ្ទាត់ចំនួនទឹកប្រាក់; ហៅដដែលពីរដងមិនបញ្ចូលពេជ្រពីរដងទេ។
- Rate limit, Helmet (CSP), ការកំណត់ទំហំ request។
- `/api/dev/pay` ដំណើរការតែក្នុងម៉ូដ mock។ `/api/admin/orders` បើកតែពេលកំណត់ `ADMIN_TOKEN`។

## អ្វីដែលមិនទាន់មាន

គណនីអ្នកប្រើ (login), ប្រព័ន្ធ refund ស្វ័យប្រវត្តិ, ការព្យាយាមបញ្ចូលម្តងទៀតពេល `failed` (បច្ចុប្បន្នត្រូវដោះស្រាយដោយដៃ តាមរយៈ `/api/admin/orders`), និង panel admin ជាក្រាហ្វិក។ ទាំងនេះអាចបន្ថែមបន្ទាប់។

> ប្រសិនបើអ្នកលក់ពិតប្រាកដ សូមប្រាកដថាមានសិទ្ធិប្រើឈ្មោះ និងរូបភាពហ្គេម (ពីអ្នកចែកចាយផ្លូវការ) ហើយអនុវត្តតាមច្បាប់ក្នុងស្រុក។
