(function () {
  "use strict";
  var T = {
    en: {
      nav_store: "Store", nav_news: "News", nav_contact: "Contact", popular: "Popular",
      s1tag: "Weekend deal", s1h: "Double crystals on first top-up", s1p: "Pick any game, choose a pack, and get bonus currency delivered in minutes.",
      s2tag: "New game", s2h: "Tidal Realm is now in the store", s2p: "Pearls and season passes, with direct delivery to your player ID.",
      s3tag: "Limited time", s3h: "Season pass bundle ends Sunday", s3p: "Save on the monthly pass and the elite upgrade when bought together.",
      rewards: "Rewards", items: "ITEMS", seeall: "See all", rewards_empty: "No rewards yet. Complete a top-up to start collecting points you can redeem later.",
      featured: "Featured games", games: "GAMES", nomatch: "No games match your search. Try another name.",
      news: "News & promotions", n1: "Arena Season 12 kicks off with new heroes and ranked rewards", n2: "Tidal Treasure Hunt event ends on 11/15, claim your pearls", n3: "Dragon's Dawn returns the Crimson Guardian skin for a limited time",
      tag: "Reliable game top-ups. Fast delivery. Secure payment.", about: "About", aboutus: "About us", visions: "Vision", policies: "Policies", top4: "Top 4 games", updates: "Get updates", subscribe: "Subscribe", accept: "We accept:", rights: "All rights reserved.", demo: "Demo storefront with sample games and prices.", support: "Support",
      direct: "Direct top-up", topup: "TOPUP", ph_search: "Search games...", ph_email: "Email address", subbed: "Thanks, you are on the list.", chat: "Support chat is not connected in this demo.",
      s_pack: "1. Choose a pack", s_id: "2. Player ID", s_pay: "3. Payment", pid: "Player ID", zone: "Zone ID", email_opt: "Email (optional)",
      m_khqr: "KHQR (Bakong)", m_card: "Visa / Mastercard", total: "Total", pay_now: "Pay now", cancel: "Cancel", close: "Close",
      scan: "Scan with your banking app to pay.", card_mock: "Card payments open the gateway page. In demo mode there is no real page.", expires_in: "Expires in",
      waiting: "Waiting for payment...", delivering: "Payment received. Delivering to your account...", simulate: "Simulate payment (demo)",
      ok_title: "Top-up complete", ok_text: "Your {item} were delivered. Order {id}.",
      bad_title: "Delivery problem", bad_text: "Your payment was received but delivery failed. Contact support with order {id}.",
      exp_title: "Payment expired", exp_text: "Order {id} was not paid in time. Please start a new order.",
      nick_ok: "Account found:", nick_bad: "Player ID not found", checking: "Checking...",
      err_invalid_player_id: "Enter a valid Player ID (5 to 16 digits).", err_invalid_zone_id: "Enter a valid Zone ID (digits only).", err_invalid_email: "That email address does not look right.",
      err_player_not_found: "Player ID not found. Check it and try again.", err_payment_unavailable: "Payments are not available right now. Try again later.", err_check_unavailable: "Cannot verify the Player ID right now. Try again later.",
      err_generic: "Something went wrong. Please try again.", err_network: "Cannot reach the server.", load_fail: "Could not load the game list. Is the server running?"
    },
    km: {
      nav_store: "ហាង", nav_news: "ព័ត៌មាន", nav_contact: "ទំនាក់ទំនង", popular: "ពេញនិយម",
      s1tag: "ពិសេសចុងសប្តាហ៍", s1h: "ទទួលគ្រីស្តាល់ទ្វេដង នៅការបញ្ចូលលើកដំបូង", s1p: "ជ្រើសរើសហ្គេម ជ្រើសកញ្ចប់ ហើយទទួលបានលុយបន្ថែមក្នុងរយៈពេលប៉ុន្មាននាទី។",
      s2tag: "ហ្គេមថ្មី", s2h: "Tidal Realm មានលក់ក្នុងហាងហើយ", s2p: "គ្រាប់ពេជ្រ និងសំបុត្រ Season ដឹកជូនដោយផ្ទាល់ទៅ ID របស់អ្នក។",
      s3tag: "រយៈពេលមានកំណត់", s3h: "កញ្ចប់ Season Pass បញ្ចប់ថ្ងៃអាទិត្យ", s3p: "សន្សំបន្ថែមពេលទិញ Pass ប្រចាំខែ និង Elite ជាមួយគ្នា។",
      rewards: "រង្វាន់", items: "ទំនិញ", seeall: "មើលទាំងអស់", rewards_empty: "មិនទាន់មានរង្វាន់ទេ។ បញ្ចូលលុយម្តង ដើម្បីចាប់ផ្តើមប្រមូលពិន្ទុ។",
      featured: "ហ្គេមពិសេស", games: "ហ្គេម", nomatch: "រកមិនឃើញហ្គេមដែលត្រូវនឹងការស្វែងរកទេ។ សូមសាកឈ្មោះផ្សេង។",
      news: "ព័ត៌មាន និងប្រូម៉ូសិន", n1: "Arena Season 12 ចាប់ផ្តើម ជាមួយវីរបុរសថ្មី និងរង្វាន់ Ranked", n2: "ព្រឹត្តិការណ៍ Tidal Treasure Hunt បញ្ចប់ថ្ងៃ 15/11 សូមយកគ្រាប់ពេជ្ររបស់អ្នក", n3: "Dragon's Dawn នាំស្គីន Crimson Guardian ត្រឡប់មកវិញក្នុងរយៈពេលមានកំណត់",
      tag: "បញ្ចូលលុយហ្គេមទុកចិត្តបាន ដឹកជូនលឿន បង់ប្រាក់សុវត្ថិភាព។", about: "អំពីយើង", aboutus: "អំពីយើង", visions: "ទស្សនវិស័យ", policies: "គោលការណ៍", top4: "ហ្គេមកំពូល ៤", updates: "ទទួលព័ត៌មានថ្មី", subscribe: "ជាវ", accept: "យើងទទួល៖", rights: "រក្សាសិទ្ធិគ្រប់យ៉ាង។", demo: "ហាងគំរូ ដែលមានហ្គេម និងតម្លៃគំរូ។", support: "ជំនួយ",
      direct: "បញ្ចូលដោយផ្ទាល់", topup: "បញ្ចូល", ph_search: "ស្វែងរកហ្គេម...", ph_email: "អាសយដ្ឋានអ៊ីមែល", subbed: "អរគុណ អ្នកបានចុះឈ្មោះហើយ។", chat: "ការជជែកជំនួយមិនទាន់តភ្ជាប់ក្នុងម៉ូដែលគំរូនេះទេ។",
      s_pack: "១. ជ្រើសរើសកញ្ចប់", s_id: "២. Player ID", s_pay: "៣. ការទូទាត់", pid: "Player ID", zone: "Zone ID", email_opt: "អ៊ីមែល (ស្រេចចិត្ត)",
      m_khqr: "KHQR (Bakong)", m_card: "Visa / Mastercard", total: "សរុប", pay_now: "បង់ប្រាក់ឥឡូវ", cancel: "បោះបង់", close: "បិទ",
      scan: "ស្កេនជាមួយកម្មវិធីធនាគាររបស់អ្នក ដើម្បីបង់ប្រាក់។", card_mock: "ការទូទាត់ដោយកាតនឹងបើកទំព័រ gateway។ ក្នុងម៉ូដសាកល្បង មិនមានទំព័រពិតទេ។", expires_in: "ផុតកំណត់ក្នុង",
      waiting: "កំពុងរង់ចាំការទូទាត់...", delivering: "បានទទួលការទូទាត់ហើយ កំពុងបញ្ចូលទៅគណនីរបស់អ្នក...", simulate: "ក្លែងធ្វើការទូទាត់ (សាកល្បង)",
      ok_title: "បញ្ចូលជោគជ័យ", ok_text: "{item} ត្រូវបានបញ្ចូលរួចរាល់។ លេខកម្ម៉ង់ {id}។",
      bad_title: "ការបញ្ចូលមានបញ្ហា", bad_text: "យើងបានទទួលការទូទាត់ហើយ តែការបញ្ចូលមិនបានសម្រេច។ សូមទាក់ទងជំនួយ ដោយប្រាប់លេខកម្ម៉ង់ {id}។",
      exp_title: "ការទូទាត់ផុតកំណត់", exp_text: "កម្ម៉ង់ {id} មិនបានបង់ទាន់ពេលទេ។ សូមធ្វើកម្ម៉ង់ថ្មី។",
      nick_ok: "រកឃើញគណនី៖", nick_bad: "រកមិនឃើញ Player ID នេះទេ", checking: "កំពុងពិនិត្យ...",
      err_invalid_player_id: "សូមបញ្ចូល Player ID ឱ្យត្រឹមត្រូវ (លេខ ៥ ដល់ ១៦ ខ្ទង់)។", err_invalid_zone_id: "សូមបញ្ចូល Zone ID ឱ្យត្រឹមត្រូវ (លេខប៉ុណ្ណោះ)។", err_invalid_email: "អាសយដ្ឋានអ៊ីមែលមិនត្រឹមត្រូវ។",
      err_player_not_found: "រកមិនឃើញ Player ID នេះទេ។ សូមពិនិត្យឡើងវិញ។", err_payment_unavailable: "ប្រព័ន្ធទូទាត់មិនទាន់ដំណើរការ សូមព្យាយាមពេលក្រោយ។", err_check_unavailable: "មិនអាចផ្ទៀងផ្ទាត់ Player ID បានឥឡូវនេះទេ។",
      err_generic: "មានបញ្ហា សូមព្យាយាមម្តងទៀត។", err_network: "មិនអាចភ្ជាប់ទៅម៉ាស៊ីនបម្រើបាន។", load_fail: "មិនអាចផ្ទុកបញ្ជីហ្គេមបាន។ តើបានបើក server ហើយឬនៅ?"
    }
  };
  var lang = "en";
  try { lang = localStorage.getItem("nimbus-lang") || "en"; } catch (e) {}

  var $ = function (s) { return document.querySelector(s); };
  var grid = $("#grid"), q = $("#q"), popBtn = $("#pop"), onlyPop = false;
  var games = [], loadFailed = false, cfg = { mock: false };

  function t(k) { return (T[lang] && T[lang][k]) || T.en[k] || k; }
  function fmt(s, o) { return s.replace(/\{(\w+)\}/g, function (_, k) { return o[k]; }); }
  function money(c) { return "$" + (c / 100).toFixed(2); }
  function errText(e) { return T[lang]["err_" + e.code] || T.en["err_" + e.code] || (e.code === "network" ? t("err_network") : t("err_generic")); }

  function api(path, opts) {
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok) { var e = new Error(d.error || "error"); e.code = d.error || "generic"; throw e; }
        return d;
      });
    }, function () { var e = new Error("network"); e.code = "network"; throw e; });
  }

  function apply() {
    document.documentElement.lang = lang === "km" ? "km" : "en";
    document.querySelectorAll("[data-i]").forEach(function (el) { el.textContent = t(el.getAttribute("data-i")); });
    document.querySelectorAll("[data-ph]").forEach(function (el) { el.placeholder = t("ph_" + el.getAttribute("data-ph")); });
    $("#en").setAttribute("aria-pressed", lang === "en");
    $("#km").setAttribute("aria-pressed", lang === "km");
    render();
  }

  // ---------------------------------------------------------------- game grid
  function art(g) {
    if (g.image) {
      return g.fit === "contain"
        ? "background:#fff url('" + g.image + "') center/contain no-repeat"
        : "background:#0b1418 url('" + g.image + "') center/cover no-repeat";
    }
    return "background:linear-gradient(145deg,hsl(" + g.hue + " 70% 42%),hsl(" + ((g.hue + 50) % 360) + " 65% 24%))";
  }
  function render() {
    var term = q.value.trim().toLowerCase(), n = 0;
    grid.innerHTML = "";
    games.forEach(function (g, i) {
      if (term && g.name.toLowerCase().indexOf(term) < 0) return;
      if (onlyPop && !g.popular) return;
      n++;
      var b = document.createElement("button");
      b.className = "game"; b.type = "button"; b.style.setProperty("--i", i);
      b.innerHTML = '<div class="art' + (g.image ? " img" : "") + '" style="' + art(g) + '">' + (g.image ? "" : g.initials) + "</div><div><b></b><small></small></div><span class=\"go\"></span>";
      b.querySelector("b").textContent = g.name;
      b.querySelector("small").textContent = g.name.split(" ")[0].toUpperCase();
      b.querySelector(".go").textContent = t("topup");
      b.addEventListener("click", function () { openDlg(g); });
      grid.appendChild(b);
    });
    $("#n").textContent = n;
    var none = $("#none");
    none.hidden = n !== 0;
    none.textContent = loadFailed ? t("load_fail") : t("nomatch");
  }

  // ---------------------------------------------------------------- checkout dialog
  var dlg = $("#dlg"), co = $("#co"), payview = $("#payview"), doneview = $("#doneview");
  var cur = null, pickId = null, orderId = null, pollT = null, tickT = null, checkT = null, expiresAt = 0, busy = false;

  function showView(name) {
    co.hidden = name !== "form"; payview.hidden = name !== "pay"; doneview.hidden = name !== "done";
  }
  function stopTimers() { clearInterval(pollT); clearInterval(tickT); clearTimeout(checkT); pollT = tickT = checkT = null; }
  function pickedPack() { return cur.packs.filter(function (p) { return p.id === pickId; })[0]; }
  function updateTotal() { var p = pickedPack(); $("#total").textContent = p ? money(p.priceCents) : "$0.00"; }
  function setErr(msg) { var e = $("#err"); e.textContent = msg || ""; e.hidden = !msg; }

  function openDlg(g) {
    cur = g; orderId = null; stopTimers(); busy = false;
    $("#dt").textContent = g.name;
    var a = $("#da"); a.style.cssText = art(g); a.textContent = g.image ? "" : g.initials; a.className = "art" + (g.image ? " img" : "");
    var p = $("#packs"); p.innerHTML = "";
    pickId = (g.packs[1] || g.packs[0]).id;
    g.packs.forEach(function (pk) {
      var b = document.createElement("button");
      b.type = "button"; b.className = "pack"; b.setAttribute("aria-pressed", pk.id === pickId);
      b.innerHTML = "<b></b><span></span>";
      b.querySelector("b").textContent = pk.amount;
      b.querySelector("span").textContent = money(pk.priceCents);
      b.title = pk.amount + " " + g.currency;
      b.addEventListener("click", function () {
        pickId = pk.id;
        p.querySelectorAll(".pack").forEach(function (x) { x.setAttribute("aria-pressed", x === b); });
        updateTotal();
      });
      p.appendChild(b);
    });
    $("#pid").value = ""; $("#zid").value = ""; $("#email").value = "";
    $("#zoneWrap").hidden = !g.needsZone;
    var nick = $("#nick"); nick.textContent = ""; nick.className = "hint";
    setErr(""); updateTotal();
    $("#buy").disabled = false;
    showView("form");
    if (!dlg.open) dlg.showModal();
  }
  function closeDlg() { stopTimers(); if (dlg.open) dlg.close(); }
  $("#close").addEventListener("click", closeDlg);
  $("#cancel").addEventListener("click", closeDlg);
  $("#cancel2").addEventListener("click", closeDlg);
  $("#doneClose").addEventListener("click", closeDlg);
  dlg.addEventListener("close", stopTimers);

  // verify the player ID shortly after typing stops
  function scheduleCheck() {
    clearTimeout(checkT);
    var nick = $("#nick"), pid = $("#pid").value.trim(), zid = $("#zid").value.trim();
    nick.className = "hint"; nick.textContent = "";
    if (!/^\d{5,16}$/.test(pid) || (cur.needsZone && !/^\d{1,6}$/.test(zid))) return;
    nick.textContent = t("checking");
    checkT = setTimeout(function () {
      var mine = pid + "/" + zid;
      api("/api/players/check?game=" + encodeURIComponent(cur.slug) + "&playerId=" + encodeURIComponent(pid) + "&zoneId=" + encodeURIComponent(zid)).then(function (r) {
        if (mine !== $("#pid").value.trim() + "/" + $("#zid").value.trim()) return;
        nick.className = "hint " + (r.valid ? "ok" : "bad");
        nick.textContent = r.valid ? t("nick_ok") + " " + r.nickname : t("nick_bad");
      }, function () { nick.textContent = ""; });
    }, 500);
  }
  $("#pid").addEventListener("input", scheduleCheck);
  $("#zid").addEventListener("input", scheduleCheck);

  co.addEventListener("submit", function (e) {
    e.preventDefault();
    if (busy) return;
    var pid = $("#pid").value.trim(), zid = $("#zid").value.trim(), email = $("#email").value.trim();
    if (!/^\d{5,16}$/.test(pid)) return setErr(t("err_invalid_player_id"));
    if (cur.needsZone && !/^\d{1,6}$/.test(zid)) return setErr(t("err_invalid_zone_id"));
    if (email && !/^[^\s@]+@[^\s@]+$/.test(email)) return setErr(t("err_invalid_email"));
    setErr(""); busy = true; $("#buy").disabled = true;
    api("/api/orders", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gameSlug: cur.slug, packId: pickId, playerId: pid, zoneId: zid, email: email, method: co.elements.method.value })
    }).then(showPayment, function (err) { setErr(errText(err)); }).then(function () { busy = false; $("#buy").disabled = false; });
  });

  function showPayment(o) {
    orderId = o.orderId; expiresAt = new Date(o.expiresAt).getTime();
    $("#payItem").textContent = o.amount + " " + o.currency;
    $("#payAmt").textContent = money(o.priceCents);
    var img = $("#qr"), msg = $("#cardmsg");
    img.hidden = !o.payment.qr; if (o.payment.qr) img.src = o.payment.qr;
    msg.hidden = !!o.payment.qr; msg.textContent = t("card_mock");
    $("#status").textContent = t("waiting");
    $("#simulate").hidden = !o.payment.mock;
    showView("pay");
    tick(); tickT = setInterval(tick, 1000);
    pollT = setInterval(poll, 2000);
  }
  function tick() {
    var s = Math.max(0, Math.round((expiresAt - Date.now()) / 1000));
    var txt = (cur && !$("#qr").hidden ? t("scan") + " " : "") + t("expires_in") + " " + Math.floor(s / 60) + ":" + ("0" + (s % 60)).slice(-2);
    $("#payHint").textContent = txt;
  }
  function poll() {
    if (!orderId) return;
    api("/api/orders/" + encodeURIComponent(orderId)).then(function (o) {
      if (o.status === "paid" || o.status === "delivering") { $("#status").textContent = t("delivering"); $("#simulate").hidden = true; }
      else if (o.status === "completed") finish(true, o);
      else if (o.status === "failed") finish(false, o);
      else if (o.status === "expired") finish(null, o);
    }, function () { /* keep polling, network hiccup */ });
  }
  function finish(ok, o) {
    stopTimers();
    var icon = $("#doneIcon"), title = $("#doneTitle"), text = $("#doneText");
    icon.className = "big" + (ok ? "" : " bad");
    if (ok) { icon.textContent = "✓"; title.textContent = t("ok_title"); text.textContent = fmt(t("ok_text"), { item: o.amount + " " + o.currency, id: o.orderId }); }
    else if (ok === false) { icon.textContent = "!"; title.textContent = t("bad_title"); text.textContent = fmt(t("bad_text"), { id: o.orderId }); }
    else { icon.textContent = "⏱"; title.textContent = t("exp_title"); text.textContent = fmt(t("exp_text"), { id: o.orderId }); }
    showView("done");
  }
  $("#simulate").addEventListener("click", function () {
    if (!orderId) return;
    api("/api/dev/pay/" + encodeURIComponent(orderId), { method: "POST" }).then(poll, function () {});
  });

  // ---------------------------------------------------------------- toast, search, language, newsletter
  var tm;
  function toast(m) { var e = $("#toast"); e.textContent = m; e.hidden = false; clearTimeout(tm); tm = setTimeout(function () { e.hidden = true; }, 2600); }
  q.addEventListener("input", render);
  popBtn.addEventListener("click", function () { onlyPop = !onlyPop; popBtn.setAttribute("aria-pressed", onlyPop); render(); });
  $("#sub").addEventListener("submit", function (e) { e.preventDefault(); $("#em").value = ""; toast(t("subbed")); });
  $("#support").addEventListener("click", function () { toast(t("chat")); });
  ["en", "km"].forEach(function (l) { $("#" + l).addEventListener("click", function () { lang = l; try { localStorage.setItem("nimbus-lang", l); } catch (e) {} apply(); }); });

  // ---------------------------------------------------------------- slider
  var slides = document.querySelectorAll(".slide"), dots = $("#dots"), idx = 0, timer;
  slides.forEach(function (s, i) {
    var d = document.createElement("button"); d.type = "button"; d.setAttribute("aria-label", "Slide " + (i + 1));
    d.addEventListener("click", function () { go(i); start(); }); dots.appendChild(d);
  });
  function go(i) {
    idx = (i + slides.length) % slides.length;
    slides.forEach(function (s, j) { s.classList.toggle("on", j === idx); });
    dots.querySelectorAll("button").forEach(function (d, j) { d.setAttribute("aria-current", j === idx); });
  }
  function start() {
    clearInterval(timer);
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    timer = setInterval(function () { go(idx + 1); }, 5000);
  }
  $(".prev").addEventListener("click", function () { go(idx - 1); start(); });
  $(".next").addEventListener("click", function () { go(idx + 1); start(); });
  go(0); start(); apply();

  // ---------------------------------------------------------------- load catalogue from the backend
  api("/api/games").then(function (d) { games = d.games; render(); }, function () { loadFailed = true; render(); });
  api("/api/config").then(function (c) { cfg = c; }, function () {});
})();

/* ---------- extra effects ---------- */
(function () {
  var root = document.documentElement;

  // theme toggle (light / dark), remembered per browser
  var btn = document.getElementById("theme");
  try { var saved = localStorage.getItem("nimbus-theme"); if (saved) root.setAttribute("data-theme", saved); } catch (e) {}
  btn.addEventListener("click", function () {
    var isLight = root.getAttribute("data-theme") === "light" ||
      (!root.getAttribute("data-theme") && window.matchMedia("(prefers-color-scheme: light)").matches);
    var next = isLight ? "dark" : "light";
    root.setAttribute("data-theme", next);
    try { localStorage.setItem("nimbus-theme", next); } catch (e) {}
  });

  // header gets a shadow after scrolling
  var header = document.querySelector("header");
  function onScroll() { header.classList.toggle("scrolled", window.scrollY > 8); }
  window.addEventListener("scroll", onScroll, { passive: true }); onScroll();

  // 3D tilt + moving shine on game tiles (event delegation, tiles are re-rendered)
  var grid = document.getElementById("grid");
  var fine = window.matchMedia("(hover: hover)").matches && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (fine) {
    grid.addEventListener("pointermove", function (e) {
      var tile = e.target.closest(".game"); if (!tile) return;
      var r = tile.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      tile.style.setProperty("--rx", ((0.5 - y) * 10).toFixed(2) + "deg");
      tile.style.setProperty("--ry", ((x - 0.5) * 10).toFixed(2) + "deg");
      tile.style.setProperty("--mx", (x * 100).toFixed(1) + "%");
      tile.style.setProperty("--my", (y * 100).toFixed(1) + "%");
    });
    grid.addEventListener("pointerout", function (e) {
      var tile = e.target.closest(".game"); if (!tile) return;
      tile.style.setProperty("--rx", "0deg"); tile.style.setProperty("--ry", "0deg");
    });
  }

  // slider progress bar, restarts on every slide change
  var slider = document.getElementById("slider");
  var bar = document.createElement("div");
  bar.className = "prog"; slider.appendChild(bar);
  function restart() { bar.style.animation = "none"; void bar.offsetWidth; bar.style.animation = ""; }
  var mo = new MutationObserver(restart);
  slider.querySelectorAll(".slide").forEach(function (s) { mo.observe(s, { attributes: true, attributeFilter: ["class"] }); });

  // press ripple on buttons
  document.addEventListener("pointerdown", function (e) {
    var b = e.target.closest(".btn, .chip-btn, .support, .sub button, .pack");
    if (!b || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    var r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2;
    var s = document.createElement("span");
    s.className = "ripple";
    s.style.cssText = "width:" + d + "px;height:" + d + "px;left:" + (e.clientX - r.left - d / 2) + "px;top:" + (e.clientY - r.top - d / 2) + "px";
    b.appendChild(s); setTimeout(function () { s.remove(); }, 600);
  });
})();
